/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sourcelab;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import java.security.SecureRandom;

/**
 *
 * @author MIKE
 */
public class Sourcelab extends Application {

    private static final String SERVER_ADDRESS = "http://localhost:56080";
    private static final int TCP_SERVER_PORT = 56080;
    private static boolean connected = false;
    static Socket s;
    private boolean status;
    private PrintTask myTask;

    @Override
    public void start(Stage primaryStage) throws IOException {
        Button btn = new Button();
        btn.setText("check server");
        btn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                System.out.println("check !");
            }
        });

        StackPane root = new StackPane();
        root.getChildren().add(btn);

        Scene scene = new Scene(root, 300, 250);

        primaryStage.setTitle("status is "+status);
        primaryStage.setScene(scene);
        status = hostAvailabilityCheck();
        myTask = new PrintTask();
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    public static boolean hostAvailabilityCheck() throws IOException {
        s = new Socket(SERVER_ADDRESS, TCP_SERVER_PORT);
        boolean available = true;
        try {
            if (s.isConnected()) {
                s.close();
            }
        } catch (UnknownHostException e) { // unknown host 
            available = false;
            s = null;
        } catch (IOException e) { // io exception, service probably not running 
            available = false;
            s = null;
        } catch (NullPointerException e) {
            available = false;
            s = null;
        }

        return available;
    }


}
